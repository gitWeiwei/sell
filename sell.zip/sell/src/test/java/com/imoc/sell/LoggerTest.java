package com.imoc.sell;


import com.imoc.entity.ProductCategory;
import com.imoc.repository.ProductCategoryRepository;
import javafx.application.Application;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class LoggerTest {

    //private final Logger logger = LoggerFactory.getLogger(LoggerTest.class);

    @Autowired(required = false)
    private ProductCategoryRepository productCategoryRepository;

    @Test
    public void test02(){
        ProductCategory productCategory = productCategoryRepository.getOne(1);
        System.out.println(productCategory.getCategoryName()+">>>>>>>>>"+productCategory.getGetCategoryType());
    }


    @Test
    public void test01(){
        String name="imooc";
        String password ="123456";
        log.info("name:{},password:{}",name,password);
        log.debug("debug....");
        log.info("info...");
        log.error("error....");
    }


}
