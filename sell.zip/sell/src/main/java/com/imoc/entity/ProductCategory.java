package com.imoc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ProductCategory {

    @Id
    @GeneratedValue
    private Integer categoryId;

    @Column
    private String categoryName;
    @Column
    private Integer getCategoryType;
    @Column
    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public Integer getGetCategoryType() {
        return getCategoryType;
    }

    public void setGetCategoryType(Integer getCategoryType) {
        this.getCategoryType = getCategoryType;
    }
}
